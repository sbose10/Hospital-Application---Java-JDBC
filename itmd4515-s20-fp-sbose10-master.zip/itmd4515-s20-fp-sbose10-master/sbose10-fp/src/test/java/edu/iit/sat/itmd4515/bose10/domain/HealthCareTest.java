/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.RollbackException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
//import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Sonita
 */
public class HealthCareTest {

    private static EntityManagerFactory emf;
    private EntityManager em;
    private EntityTransaction tx;

    /**
     *
     */
    public HealthCareTest() {
    }

    /**
     *
     */
    @BeforeAll
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory("itmd4515testPU");

    }

    /**
     *
     */
    @AfterAll
    public static void tearDownClass() {
        emf.close();
    }

    /**
     *
     */
    @BeforeEach
    public void setUp() {

        em = emf.createEntityManager();
        tx = em.getTransaction();
        HealthCare hc = new HealthCare("Kim", "Kardashian", 35,
                "999",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS);

        tx.begin();
        em.persist(hc);
        tx.commit();
    }

    /**
     *
     */
    @AfterEach
    public void tearDown() {

        HealthCare hc = em.createQuery("select h from HealthCare h where h.AptID = :AptID",
                HealthCare.class)
                .setParameter("AptID", "999")
                .getSingleResult();

        tx.begin();
        em.remove(hc);
        tx.commit();
        em.close();
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //

    /**
     *
     */
    @Test
    public void BeforeEachWorks() {
    }

    /**
     *
     */
    @Test
    public void AfterEachWorks() {
    }

    /**
     *
     */
    @Test
    public void createTestPass() {
        HealthCare hc = new HealthCare("Kim", "Kardashian", 35,
                "1",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS);

        tx.begin();

     /*   Doctor doc1 = new Doctor("Shalini","Bose","12","@google"); //11
        Appointment app1 = new Appointment("Fever", localdate.now); //100
        Patient pat1 = new Patient("Shalini","Bose","12","@google"); //10
        
        doc1.setappList(app1);
        app1.setPatient(pat1); */
        
     
        
        // UNMANAGED by JPA
        assertNull(hc.id);
        System.out.println("Prior to persist: generated value for id is null: " + hc.toString());

        em.persist(hc);
        System.out.println("Post persist:generated value is still null: " + hc.toString());

        tx.commit();

        assertNotNull(hc.id);
        assertTrue(hc.id > 0);

        System.out.println("Post commit - generated value is available: " + hc.toString());

        // cleanup 
        tx.begin();
        em.remove(hc);
        tx.commit();

    }

    /**
     *
     */
    @Test
    public void createTestFail() {
        HealthCare hc = new HealthCare("Kim", "Kardashian", 35,
                "999",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS);

        assertThrows(RollbackException.class, () -> {
            tx.begin();
            em.persist(hc);
            tx.commit();
        });

    }

    /**
     *
     */
    @Test
    public void readTest() {

        HealthCare hc = em.createQuery("select h from HealthCare h",
                HealthCare.class).getSingleResult();

        HealthCare reFindTheEntity = em.find(HealthCare.class, hc.id);

        System.out.println("The Patient ID has been retrieved :" + reFindTheEntity.toString());

        assertNotNull(reFindTheEntity);

        assertEquals(reFindTheEntity, hc);
    }

    /**
     *
     */
    @Test
    public void updateTest() {

        HealthCare hc = em.createQuery("select h from HealthCare h where h.AptID = :AptID",
                HealthCare.class)
                .setParameter("AptID", "999")
                .getSingleResult();

        tx.begin();
        hc.setHcDepartment(HcDepartment.GYN);
        hc.setPAge(33);
        tx.commit();

        HealthCare reFindTheEntity = em.find(HealthCare.class, hc.id);
        System.out.println("Updated Age and Department" + reFindTheEntity.toString());

        assertEquals(hc.getHcDepartment(), reFindTheEntity.getHcDepartment());
        assertEquals(hc.getPAge(), reFindTheEntity.getPAge());

    }

    /**
     *
     */
    @Test
    public void deleteTest() {

        HealthCare hc = new HealthCare("Kyle", "Jenner", 35,
                "2",
                LocalDate.now(),
                "Pain",
                HcDepartment.GAS);

        tx.begin();
        em.persist(hc);
        tx.commit();

        // assert created successfully before we remove it
        assertNotNull(hc.id);

        tx.begin();
        em.remove(hc);
        tx.commit();

        System.out.println("removeTest just removed: " + hc.toString());

        HealthCare reFindFromDatabase = em.find(HealthCare.class, hc.id);
        assertNull(reFindFromDatabase);

    }

}
