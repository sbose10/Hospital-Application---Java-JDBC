/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Sonita
 */
public class RelationshipTest extends AbstractJPATest {

    /**
     *
     */
    public RelationshipTest() {
    }

    /**
     *
     */
    @Test
    public void testDoctor_Appointment_OneToMany_Unidirectional() {

        Doctor d1 = new Doctor("Sonita", "bose", LocalDate.of(2014, Month.JANUARY, 1), "s@gmail.com");

        Appointment ap1 = new Appointment("Stomach Pain", LocalDateTime.of(2021, 12, 5, 10, 0), LocalDateTime.of(2020, Month.MARCH, 9, 10, 0));

        ap1.setDoctor(d1);

        tx.begin();
        em.persist(d1);
        em.persist(ap1);
        tx.commit();

        assertEquals(d1, ap1.getDoctor());
        assertTrue(d1.getId() > 0);
        assertTrue(ap1.getId() > 0);

    }

    /**
     *
     */
    @Test
    public void testPatient_Appointmnet_OneToMany_Unidirectional() {

        Patient p1 = new Patient("Roni", "Khut", LocalDate.of(1987, Month.MARCH, 3), "Sb@gmail.com");
        Appointment ap1 = new Appointment("Stomach Pain", LocalDateTime.of(2021, 7, 5, 10, 0), LocalDateTime.of(2020, Month.MARCH, 9, 10, 0));

        ap1.setPatient(p1);

        tx.begin();
        em.persist(p1);
        em.persist(ap1);
        tx.commit();

        assertEquals(p1, ap1.getPatient());
        assertTrue(p1.getId() > 0);
        assertTrue(ap1.getId() > 0);

    }

    /**
     *
     */
    @Test
    public void testDoctor_Patient_ManyToMany() {

        Doctor d1 = new Doctor("Swati", "Pai", LocalDate.of(1975, Month.MAY, 1), "swati_pai@gmail.com");
        Doctor d2 = new Doctor("Sanjay", "Pai", LocalDate.of(1970, Month.JUNE, 1), "sanjay_pai@gmail.com");

        Patient p1 = new Patient("Roni", "Roy", LocalDate.of(1987, Month.MARCH, 3), "Sb@gmail.com");
        Patient p2 = new Patient("Arnav", "Kros", LocalDate.of(1989, Month.APRIL, 4), "arnav@gmail.com");

        Appointment ap1 = new Appointment("Chest Pain", LocalDateTime.of(2021, 7, 5, 10, 10), LocalDateTime.of(2020, Month.APRIL, 10, 10, 0));
        Appointment ap2 = new Appointment("Back Pain", LocalDateTime.of(2021, 7, 5, 10, 30), LocalDateTime.of(2020, Month.APRIL, 9, 10, 0));
        Appointment ap3 = new Appointment("Tummy Pain", LocalDateTime.of(2021, 7, 5, 10, 40), LocalDateTime.of(2020, Month.APRIL, 19, 10, 0));

        ap1.setDoctor(d1);
        ap1.setPatient(p1);

        ap2.setDoctor(d1);
        ap2.setPatient(p2);

        ap3.setDoctor(d2);
        ap3.setPatient(p2);

        d1.addPatient(p1);
        d1.addPatient(p2);
        d2.addPatient(p2);

        tx.begin();
        em.persist(d1);
        em.persist(d2);
        em.persist(p1);
        em.persist(p2);
        em.persist(ap1);
        em.persist(ap2);
        em.persist(ap3);
        tx.commit();

        Doctor findDoctor1 = em.find(Doctor.class, d1.getId());
        System.out.println("GetPatiet list for ****Doctor 1**** Birdirection - Many to Many - side   \t\t");
        System.out.println(d1.toString());
        for (Patient patient : d1.getPatients()) {
            System.out.println("\t" + patient.toString());
        }

        Doctor findDoctor2 = em.find(Doctor.class, d2.getId());
        System.out.println("GetPatiet list for ****Doctor 2**** Birdirection - Many to Many - side for  \t\t");
        System.out.println(d2.toString());
        for (Patient patient : d2.getPatients()) {
            System.out.println("\t" + patient.toString());
        }

        Patient findPatient1 = em.find(Patient.class, p1.getId());

        System.out.println("Birdirection - Many to Many - Inverse side for Patient 1 \t\t");
        System.out.println(p1.toString());
        for (Doctor doctor : p1.getDoctor()) {
            System.out.println("\t" + doctor.toString());
        }

        Patient findPatient2 = em.find(Patient.class, p2.getId());

        System.out.println("Birdirection - Many to Many - Inverse side for Patient 2 \t\t");
        System.out.println(p2.toString());
        for (Doctor doctor : p2.getDoctor()) {
            System.out.println("\t" + doctor.toString());
        }

        System.out.println("************************************" + findDoctor1.getPatients().size());
        System.out.println("************************************" + findDoctor2.getPatients().size());

        assertTrue(findDoctor1.getPatients().size() == 2);
        assertTrue(findPatient1.getDoctor().size() == 1);
        // assertTrue (findPatient2.getDoctor().size() ==2);

        //Remove p1 from d1 and p2 from d1
        tx.begin();
        d1.removePatient(p1);
        d1.removePatient(p2);
        tx.commit();

        assertTrue(p1.getDoctor().isEmpty());
        assertTrue(d1.getPatients().isEmpty());
        assertTrue(p2.getDoctor().size() == 1);

        tx.begin();
        em.remove(ap1);
        em.remove(ap2);
        em.remove(ap3);
        em.remove(p1);
        em.remove(p2);
        em.remove(d1);
        em.remove(d2);
        tx.commit();
    }

    /**
     *
     */
    @Test
    public void testDoctor_Department_OneToOne() {

        Department dpt1 = new Department(HcDepartment.GEN);
        Doctor d1 = new Doctor("Hulla", "Panda", LocalDate.of(1965, Month.AUGUST, 1), "hulla_panda@gmail.com");

        d1.setDepartment(dpt1);

        tx.begin();
        em.persist(dpt1);
        em.persist(d1);
        tx.commit();

        assertEquals(d1.getDepartment().getHcDepartment().getLabel(), "Physician");

    }
    
    
   
}
