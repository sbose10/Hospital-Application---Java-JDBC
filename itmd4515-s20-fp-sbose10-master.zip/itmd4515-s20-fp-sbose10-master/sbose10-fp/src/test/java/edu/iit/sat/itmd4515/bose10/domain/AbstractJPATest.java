/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

/**
 *
 * @author Sonita
 */
abstract class AbstractJPATest {
    private static EntityManagerFactory emf;
    protected EntityManager em;
    protected EntityTransaction tx;

    @BeforeAll
    public static void setUpClass() {
        emf = Persistence.createEntityManagerFactory("itmd4515testPU");
    }

    @AfterAll
    public static void tearDownClass() {
        emf.close();
    }

    @BeforeEach
    public void setUp() {
        em = emf.createEntityManager();
        tx = em.getTransaction();
        HealthCare hc = new HealthCare("Kim", "Kardashian", 35,
                "999",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS);

        tx.begin();
        em.persist(hc);
        tx.commit();
    }
        
    @AfterEach
    public void tearDown() {

        HealthCare hc = em.createQuery("select h from HealthCare h where h.AptID = :AptID",
                HealthCare.class)
                .setParameter("AptID", "999")
                .getSingleResult();

        tx.begin();
        em.remove(hc);
        tx.commit();
        em.close();
    }
}
