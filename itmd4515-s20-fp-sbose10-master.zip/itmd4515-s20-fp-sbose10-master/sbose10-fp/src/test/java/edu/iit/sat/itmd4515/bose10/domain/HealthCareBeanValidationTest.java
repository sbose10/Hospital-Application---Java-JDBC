/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Sonita
 */
public class HealthCareBeanValidationTest {

    private static Validator validator;

    /**
     *
     */
    public HealthCareBeanValidationTest() {
    }

    /**
     *
     */
    @BeforeAll
    public static void setUpClass() {

        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    /**
     *
     */
    @AfterAll
    public static void tearDownClass() {
    }

    /**
     *
     */
    @BeforeEach
    public void setUp() {
    }

    /**
     *
     */
    @AfterEach
    public void tearDown() {
    }

    /**
     *
     */
    @Test
    public void testValidationGoodPatient() {
        HealthCare gp = new HealthCare("Kim", "Kardashian", 35,
                "kk@gmail.com",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS, "999");

        Set<ConstraintViolation<HealthCare>> constraintViolations
                = validator.validate(gp);

        assertEquals(0, constraintViolations.size());

    }

    //checked for 3 constraints. Last name as NULL, size and incorrect email address

    /**
     *
     */
    @Test
    public void testValidationBadPatientEmail() {
        HealthCare gp = new HealthCare("Kim", "Kardashian", 35,
                "kkgmail.com",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS, "999");

        Set<ConstraintViolation<HealthCare>> constraintViolations
                = validator.validate(gp);

        assertEquals(1, constraintViolations.size());

        assertEquals(
                "must be a well-formed email address",
                constraintViolations.iterator().next().getMessage()
        );

    }

    /**
     *
     */
    @Test
    public void testValidationBadPatientData() {
        HealthCare gp = new HealthCare("Kim", "", 35,
                "kkgmail.com",
                LocalDate.now(),
                "stomach Pain",
                HcDepartment.GAS, "999");

        Set<ConstraintViolation<HealthCare>> constraintViolations
                = validator.validate(gp);

        assertEquals(3, constraintViolations.size());

    }

}
