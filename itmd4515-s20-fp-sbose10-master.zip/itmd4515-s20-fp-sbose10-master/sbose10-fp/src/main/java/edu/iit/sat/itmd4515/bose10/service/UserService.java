/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;
import  edu.iit.sat.itmd4515.bose10.domain.security.User;

import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author Sonita
 */
@Stateless
public class UserService extends AbstractService<User> {
    
    /**
     *constructor
     */
    public UserService() {
        super(User.class);
    }

    /**
     *list of all the users
     * @return
     */
    @Override
    public List<User> findAll() {
        return em.createNamedQuery("User.findAll", entityClass).getResultList();
    }
    
    /**
     *list of all the usernames
     * @param username
     * @return
     */
    public User findByUsername(String username) {
        return em.find(User.class, username);
    }
    
}
