/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.validation.constraints.Email;
import javax.validation.constraints.Future;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

/**
 *
 * @author Sonita
 */
@Entity

public class HealthCare extends EntityID {

  //  @Id
  //  @GeneratedValue(strategy = GenerationType.IDENTITY)
  //  private Long PID;

    @NotBlank(message = "Please enter your first name - required")
    @Column(nullable = false)
    @Size(min = 2, max = 20)
    private String PFname;

    @NotBlank(message ="Please enter your last name - required")
    @Column(nullable = false)
    @Size(min = 2, max = 20)
    private String PLastName;

    @Column(nullable = false)
    private Integer PAge;

    
    @Email
    //@NotBlank
    private String email;

    @FutureOrPresent
    private LocalDate AppointmentDate;
    
    //@FutureOrPresent
    //private LocalDateTime aptd;
    @NotBlank(message ="Please enter your symptom - required") 
    private String Symptom;

    @NotNull
    @Enumerated(EnumType.STRING)
    private HcDepartment HcDepartment;

    @NotBlank
    @Column(unique = true)
    private String AptID;

    /**
     *
     */
    public HealthCare() {
    }

    /**
     *
     * @param PFname
     * @param PLastName
     * @param PAge
     * @param AptID
     */
    public HealthCare(String PFname, String PLastName, Integer PAge, String AptID) {
        this.PFname = PFname;
        this.PLastName = PLastName;
        this.PAge = PAge;
        this.AptID = AptID;
    }

    /**
     *
     * @param PFname
     * @param intgr
     * @param string2
     * @param AptID
     * @param ld
     * @param Symptom
     * @param HcDepartment
     * @param hd
     */
    public HealthCare(String PFname, String PLastName, Integer PAge, String AptID, LocalDate AppointmentDate, String Symptom, HcDepartment HcDepartment) {
        this.PFname = PFname;
        this.PLastName = PLastName;
        this.PAge = PAge;
        this.AptID = AptID;
        this.AppointmentDate = AppointmentDate;
        this.Symptom = Symptom;
        this.HcDepartment = HcDepartment;
    }

    /**
     *
     * @param string
     * @param string1
     * @param PLastName
     * @param string2
     * @param email
     * @param string3
     * @param Symptom
     * @param HcDepartment
     * @param string4
     * @param AptID
     */
    public HealthCare(String PFname, String PLastName, Integer PAge, String email, LocalDate AppointmentDate, String Symptom, HcDepartment HcDepartment, String AptID) {
        this.PFname = PFname;
        this.PLastName = PLastName;
        this.PAge = PAge;
        this.email = email;
        this.AppointmentDate = AppointmentDate;
        this.Symptom = Symptom;
        this.HcDepartment = HcDepartment;
        this.AptID = AptID;
    }

   /* public HealthCare(String PFname, String PLastName, Integer PAge, String email, LocalDateTime AppointmentDate, LocalDateTime aptd, String Symptom, HcDepartment HcDepartment, String AptID) {
        this.PFname = PFname;
        this.PLastName = PLastName;
        this.PAge = PAge;
        this.email = email;
        this.AppointmentDate = AppointmentDate;
        this.aptd = aptd;
        this.Symptom = Symptom;
        this.HcDepartment = HcDepartment;
        this.AptID = AptID;
    }*/



    /**
     * Set the value of PID
     *
     * @return 
     */
   /* public void setPID(Long PID) {
        this.PID = PID;
    }
 */
    public String getPFname() {
        return PFname;
    }

    /**
     *
     * @param PFname
     */
    public void setPFname(String PFname) {
        this.PFname = PFname;
    }

    /**
     *
     * @return
     */
    public String getPLastName() {
        return PLastName;
    }

    /**
     *
     * @param PLastName
     */
    public void setPLastName(String PLastName) {
        this.PLastName = PLastName;
    }

    /**
     *
     * @return
     */
    public Integer getPAge() {
        return PAge;
    }

    /**
     *
     * @param PAge
     */
    public void setPAge(Integer PAge) {
        this.PAge = PAge;
    }

    /**
     *
     * @return
     */
    public LocalDate getAppointmentDate() {
        return AppointmentDate;
    }

    /**
     *
     * @param AppointmentDate
     */
    public void setAppointmentDate(LocalDate AppointmentDate) {
        this.AppointmentDate = AppointmentDate;
    }

    /**
     *
     * @return
     */
    public HcDepartment getHcDepartment() {
        return HcDepartment;
    }

    /**
     *
     * @param HcDepartment
     */
    public void setHcDepartment(HcDepartment HcDepartment) {
        this.HcDepartment = HcDepartment;
    }

    /**
     *
     * @return
     */
    public String getAptID() {
        return AptID;
    }

    /**
     *
     * @param AptID
     */
    public void setAptID(String AptID) {
        this.AptID = AptID;
    }

    /**
     *
     * @return
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return
     */
    public String getSymptom() {
        return Symptom;
    }

    /**
     *
     * @param Symptom
     */
    public void setSymptom(String Symptom) {
        this.Symptom = Symptom;
    }

    @Override
    public String toString() {
        return "HealthCare{" + "id=" + id + ", PFname=" + PFname + ", PLastName=" + PLastName + ", PAge=" + PAge + ", email=" + email + ", AppointmentDate=" + AppointmentDate + ", Symptom=" + Symptom + ", HcDepartment=" + HcDepartment + ", AptID=" + AptID + '}';
    }

}
