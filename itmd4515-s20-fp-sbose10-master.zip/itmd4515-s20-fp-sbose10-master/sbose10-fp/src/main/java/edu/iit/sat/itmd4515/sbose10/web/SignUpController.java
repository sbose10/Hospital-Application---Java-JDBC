/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.domain.security.Group;
import edu.iit.sat.itmd4515.bose10.domain.security.User;
import edu.iit.sat.itmd4515.bose10.service.GroupService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import edu.iit.sat.itmd4515.bose10.service.UserService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.enterprise.SecurityContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class SignUpController {

    private User user;
    private Patient patient;

    @Inject
    private UserService userSvc;

    @Inject
    private PatientService patientSvc;

    @EJB
    GroupService groupSvc;

    @Inject
    PatientController patientController;

    @Inject
    LoginController loginController;

    /**
     *Constructor
     */
    public SignUpController() {
    }

    private static final Logger LOG = Logger.getLogger(SignUpController.class.getName());

    @Inject
    private SecurityContext securityContext;
    @Inject
    private FacesContext facesContext;

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the SignUpController.postConstruct method");
        patient = new Patient();
        user = new User();

    }

    /**
     *method to register users 
     * @return
     */
    public String registerUser() {

        LOG.info("Inside the SignUpController.Register method" + patient.toString());
        //  Group patientGroup = new Group("PATIENT_GROUP", "Group of Patients");
        Group patientGroup = groupSvc.findByGroupname("PATIENT_GROUP");
        LOG.info("Inside the SignUpController.PatienGroup method" + patientGroup.toString());
        LOG.info("Inside the SignUpController.PatienGroup method" + user.getUserName());
        user.addGroup(patientGroup);
        userSvc.create(user);
        patient.setUser(user);
        patientSvc.create(patient);

        HttpServletRequest req = (HttpServletRequest) facesContext.getExternalContext().getRequest();
        try {
            req.logout();
        } catch (ServletException ex) {
            LOG.log(Level.SEVERE, null, ex);
            return "/error.xhtml";
        }
        LOG.info("Inside the SignUpController.Register usser loggingout byeeeeeeee");
        return "/login.xhtml?faces-redirect=true";
    }

    /**
     *
     * @return
     */
    public User getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public Patient getPatient() {
        return patient;
    }

    /**
     *
     * @param patient
     */
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

}
