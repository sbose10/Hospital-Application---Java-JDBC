/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;

import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.sbose10.web.AppointmentController;
import edu.iit.sat.itmd4515.sbose10.web.LoginController;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.NoResultException;

/**
 *
 * @author Sonita
 */
@Named
@Stateless
public class PatientService extends AbstractService<Patient> {

    private static final Logger LOG = Logger.getLogger(PatientService.class.getName());

    /**
     *
     */
    public PatientService() {
        super(Patient.class);
    }

    /**
     *
     * @return
     */
    @Override
    public List<Patient> findAll() {
        return em.createNamedQuery("Patient.findAll", entityClass).getResultList();
        //return em.createNamedQuery("Patient.findByFirstName", entityClass).getResultList();
    }

    /**
     *method to find the username and sent it as a parameter
     * @param username
     * @return
     */
    public Patient findByUsername(String username) {
        Patient p = null;
        //try {
        //    LOG.info("in patient service ******* loginController.isDoctor() "+loginController.isDoctor());
        //  LOG.info("in patient service ******* loginController.Admin() "+loginController.isAdmin());
        // LOG.info("in patient service ******* loginController.Patient() "+loginController.isPatient());
        p = em.createNamedQuery("Patient.findByUserName", Patient.class)
                .setParameter("userName", username)
                .getSingleResult();

        /*  }catch(NoResultException e) {
            LOG.info("Patient Service Exception 1 " + e);
             try {
                 if(loginController.isDoctor())
                FacesContext.getCurrentInstance().getExternalContext().dispatch("unauthorizedErrorPage.html");
             } catch (IOException ex) {
                 LOG.info("Patient Service IOException " + ex);
                 Logger.getLogger(PatientService.class.getName()).log(Level.SEVERE, "Could not find patient by that name", ex);
             }
        } */
        return p;
    }

}
