/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import edu.iit.sat.itmd4515.bose10.domain.security.Group;
import edu.iit.sat.itmd4515.bose10.domain.security.User;
import edu.iit.sat.itmd4515.bose10.service.DoctorService;
import edu.iit.sat.itmd4515.bose10.service.GroupService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import edu.iit.sat.itmd4515.bose10.service.UserService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.SecurityContext;
import javax.security.enterprise.authentication.mechanism.http.AuthenticationParameters;
import javax.security.enterprise.credential.Credential;
import javax.security.enterprise.credential.Password;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class AddNewDoctorController {

    private User user;

    private Doctor doctor;

    @Inject
    private UserService userSvc;

    @Inject
    private DoctorService doctorSvc;

    @EJB
    GroupService groupSvc;

    @Inject
    DoctorController doctorController;

    @Inject
    LoginController loginController;

    /**
     * constructor
     */
    public AddNewDoctorController() {
    }

    private static final Logger LOG = Logger.getLogger(AddNewDoctorController.class.getName());

    @Inject
    private SecurityContext securityContext;
    @Inject
    private FacesContext facesContext;

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the AddNewDoctorController.postConstruct method");
        doctor = new Doctor();
        user = new User();

    }

    /**
     *method to add a new doctor for admin 
     * @return
     * 
     * Method for Admin to add new Doctor
     */
    public String addNewDoctor() {

        LOG.info("Inside the AddNewDoctorController.Register method" + doctor.toString());
        
        Group doctorGroup = groupSvc.findByGroupname("DOCTOR_GROUP");
        LOG.info("Inside the AddNewDoctorController.DoctorGroup method" + doctorGroup.toString());
        LOG.info("Inside the AddNewDoctorController.DoctorGroup method" + user.getUserName());
        user.addGroup(doctorGroup);
        userSvc.create(user);
        doctor.setUser(user);
        doctorSvc.create(doctor);

       
        LOG.info("Inside the AddNewDoctorController.AddNewDoctor - Added new Doctor");
        return "/Admin/viewAllDocsAdmin.xhtml?faces-redirect=true";
    }

    /**
     *
     * @return
     */
    public User getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    public Doctor getDoctor() {
        return doctor;
    }

    /**
     *
     * @param doctor
     */
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

  

}
