/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Sonita
 */
@Entity
@NamedQuery(name = "Department.findAll", query = "select dpt from Department dpt")
@NamedQuery(name = "Department.findById", query = "select dpt from Department dpt where dpt.id = :id")
@NamedQuery(name = "Department.findByHcDepartment", query = "select dpt from Department dpt where dpt.HcDepartment = :HcDepartment")
public class Department extends EntityID{
    
    /**
     *
     */
    public Department() {
    }

     //@OneToOne
     //private Doctor doctor;
     
    @NotNull
    @Enumerated(EnumType.STRING)
    private HcDepartment HcDepartment;

    /**
     *parameterized constructor passing the department as a parameter
     * @param HcDepartment
     */
    public Department(HcDepartment HcDepartment) {
        this.HcDepartment = HcDepartment;
    }

    /**
     *
     * @return
     */
    public HcDepartment getHcDepartment() {
        return HcDepartment;
    }

    /**
     *
     * @param HcDepartment
     */
    public void setHcDepartment(HcDepartment HcDepartment) {
        this.HcDepartment = HcDepartment;
    }

    
    
}
