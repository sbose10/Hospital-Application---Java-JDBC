/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import edu.iit.sat.itmd4515.bose10.domain.HcDepartment;
import edu.iit.sat.itmd4515.bose10.domain.HealthCare;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.transaction.UserTransaction;

/**
 *
 * @author Sonita
 */
@WebListener
public class ServletContextDBPopulator implements ServletContextListener {

    private static final Logger LOG = Logger.getLogger(ServletContextDBPopulator.class.getName());
    @PersistenceContext(name = "itmd4515PU")
    EntityManager em;

    @Resource
    UserTransaction tx;

    @Override
    public void contextDestroyed(ServletContextEvent sce) {

        LOG.info("Servlet Context Destroyed");

        ServletContextListener.super.contextDestroyed(sce); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {

                try {
            LOG.info("Servlet Context Initialized");
            
            Doctor doc1 = new Doctor("Kelly", "Rochester", LocalDate.of(1987, Month.MAY, 1), "Krochester@gmail.com");
            //HealthCare hc = new HealthCare("Rinky", lname, Integer.SIZE, email, hcAppointmentDate, Symptom, HcDepartment.valueOf(HcDept), AptID);
            tx.begin();
            em.persist(doc1);
            tx.commit();
            
            ServletContextListener.super.contextInitialized(sce);
            
        } catch (Exception e) {
            LOG.log(Level.SEVERE, e.getMessage(), e);
        }
    }

}
