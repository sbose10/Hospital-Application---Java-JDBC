/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import edu.iit.sat.itmd4515.bose10.domain.security.Group;
import edu.iit.sat.itmd4515.bose10.domain.security.User;
import edu.iit.sat.itmd4515.bose10.service.DoctorService;
import edu.iit.sat.itmd4515.bose10.service.GroupService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import edu.iit.sat.itmd4515.bose10.service.UserService;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.SecurityContext;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class NavController {

    /**
     *
     */
    public NavController() {
    }

    private static final Logger LOG = Logger.getLogger(NavController.class.getName());

    @Inject
    private SecurityContext securityContext;
    @Inject
    private FacesContext facesContext;
    @Inject
    private LoginController loginController;

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the NavController.postConstruct method");

    }

    /**
     * method for the book appointment tab for patients based on user roles like
     * admin doctor patient The method allows only patient to book an
     * appointment Any other role would be directed to an unauthorized page
     *
     * @return
     */
    public String bookAppointment() {

        LOG.info("in bookAppointment  ******* loginController.isDoctor() " + loginController.isDoctor());
        LOG.info("in bookAppointment  ******* loginController.Admin() " + loginController.isAdmin());
        LOG.info("in bookAppointment  ******* loginController.Patient() " + loginController.isPatient());

        if ((loginController.isPatient() && loginController.isDoctor() && !loginController.isAdmin()) || (loginController.isPatient() && !loginController.isDoctor() && loginController.isAdmin())) {    //      FacesContext.getCurrentInstance().getExternalContext().dispatch("unauthorizedErrorPage.xhtml");

            return "unauthorizedErrorPage.xhtml";

        }

        return "Client.xhtml";

    }

}
