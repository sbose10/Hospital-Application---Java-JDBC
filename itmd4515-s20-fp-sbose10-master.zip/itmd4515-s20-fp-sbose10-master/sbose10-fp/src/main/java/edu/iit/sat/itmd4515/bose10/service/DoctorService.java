/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;
import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author Sonita
 */
@Stateless
public class DoctorService extends AbstractService<Doctor> {
    
    /**
     *constructor
     */
    public DoctorService() {
        super(Doctor.class);
    }

    /**
     *list of all doctors
     * @return
     */
    @Override
    public List<Doctor> findAll() {
        return em.createNamedQuery("Doctor.findAll", entityClass).getResultList();

    }
    
    /**
     *list of username where username is a doctor
     * @param username
     * @return
     */
    public Doctor findByUsername(String username){
        return em.createNamedQuery("Doctor.findByUserName", Doctor.class)
                .setParameter("userName", username)
                .getSingleResult();
    }
     
    /**
     *method to update the appointment and manage it 
     * @param apt
     */
    public void appointmentUpdate(Appointment apt) {
     
        Appointment currentRowFromDatabase = em.find(Appointment.class, apt.getId());

        currentRowFromDatabase.setAptTime(apt.getAptTime());
        
       
        em.merge(currentRowFromDatabase);

    }
    
    /**
     *in order to remove an entity, it has to be managed
     * @param docId
     */
    public void removeDoctor(Long docId)
    {
         
         Doctor currentRowFromDatabase = em.find(Doctor.class, docId);
        
        em.remove(currentRowFromDatabase);
        
    }
    
    /**
     *in order to remove an entity, it has to be managed
     * @param apt
     */
    public void appointmentDelete(Appointment apt){
        // in order to remove an entity, it has to be managed
        Appointment currentRowFromDatabase = em.find(Appointment.class, apt.getId());;

        em.remove(currentRowFromDatabase);
    }
    
    
    
}
     
     
    