/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import org.eclipse.persistence.annotations.CascadeOnDelete;

/**
 *
 * @author Sonita
 */
@Entity
@NamedQuery(name = "Appointment.findAll", query = "select p from Appointment p")
@NamedQuery(name = "Appointment.findMyAppointments", query = "select p from Appointment p where p.doctor.id = :id")
@NamedQuery(name="Appointment.findAppointmentById", query= "select p from Appointment p where p.id = :id")
public class Appointment extends EntityID {

    @ManyToOne
    private Doctor doctor;
 
    
    @OneToOne 
    private Patient patient;

    @NotBlank
    private String Symptom;
    
    
    /**
     * default constructor and is called when the object is created.
     */
    public Appointment() {
    }

    /**
     *variable for appointment time with the Future constraint
     */
    @FutureOrPresent
    protected LocalDateTime AptTime;

    /**
     *
     */
    protected LocalDateTime AptUpdatedTime;

    /**
     *
     * @param doctor
     * @param ptnt
     * @param string
     * @param ldt
     * @param ldt1
     */
    public Appointment(Doctor doctor, Patient patient, String Symptom, LocalDateTime AptTime, LocalDateTime AptUpdatedTime) {
        this.doctor = doctor;
        this.patient = patient;
        this.Symptom = Symptom;
        this.AptTime = AptTime;
        this.AptUpdatedTime = AptUpdatedTime;
    }

    /**
     *
     * @param string
     * @param ldt
     * @param ldt1
     */
    public Appointment(String Symptom, LocalDateTime AptTime, LocalDateTime AptUpdatedTime) {
        this.Symptom = Symptom;
        this.AptTime = AptTime;
        this.AptUpdatedTime = AptUpdatedTime;
    }



    @PrePersist
    private void prePersist() {

        //AptTime = LocalDateTime.now();
        //System.out.println("***************************"+AptTime);
    }

    @PreUpdate
    private void preUpdate() {

        AptUpdatedTime = LocalDateTime.now();
    }

    /**
     * Get the value of AptTime
     *
     * @return the value of AptTime
     */
    public LocalDateTime getAptTime() {
        return AptTime;
    }

    /**
     * Set the value of AptTime
     *
     * @param AptTime new value of AptTime
     */
    public void setAptTime(LocalDateTime AptTime) {
        this.AptTime = AptTime;
    }

    /**
     *
     * @return
     */
    public LocalDateTime getAptUpdatedTime() {

        return AptUpdatedTime;
    }

    /**
     *
     * @param AptUpdatedTime
     */
    public void setAptUpdatedTime(LocalDateTime AptUpdatedTime) {
        this.AptUpdatedTime = AptUpdatedTime;
    }

    @Override
    public String toString() {
        return "Appointment{" + "id=" + id + "AptTime=" + AptTime + ", AptUpdatedTime=" + AptUpdatedTime + '}';
    }

    /**
     *
     * @return
     */
    public Doctor getDoctor() {
        return doctor;
    }

    /**
     *
     * @param doctor
     */
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    /**
     *
     * @return
     */
    public Patient getPatient() {
        return patient;
    }

    /**
     *
     * @param patient
     */
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    /**
     *
     * @return
     */
    public String getSymptom() {
        return Symptom;
    }

    /**
     *
     * @param Symptom
     */
    public void setSymptom(String Symptom) {
        this.Symptom = Symptom;
    }

    /**
     *
     * @param valueOf
     * @return
     */
    public Appointment find(Long valueOf) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
}
