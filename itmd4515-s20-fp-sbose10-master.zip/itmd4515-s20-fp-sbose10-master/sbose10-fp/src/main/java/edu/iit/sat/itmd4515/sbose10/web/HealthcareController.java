/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;
import edu.iit.sat.itmd4515.bose10.domain.HealthCare;
import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.service.HealthcareService;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class HealthcareController {

    private static final Logger LOG = Logger.getLogger(HealthcareController.class.getName());

    private HealthCare healthcare;
    
    
    @EJB HealthcareService HcSvc;
    
    /**
     *
     */
    public HealthcareController() {
    }

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the HealthcareController.postConstruct method");
        healthcare = new HealthCare();
        
    }
    
    /**
     *
     * @return
     */
    public String savePatientDetails(){
        LOG.info("Inside Healthcare: " + healthcare.toString());
        
        HcSvc.create(healthcare);
        return "welcomePatient.xhtml";
        
        
    }

    /**
     *
     * @return
     */
    public HealthCare getHealthCare() {
        return healthcare;
    }

    /**
     *
     * @param healthcare
     */
    public void setHealthCare(HealthCare healthcare) {
        this.healthcare = healthcare;
    }

}
