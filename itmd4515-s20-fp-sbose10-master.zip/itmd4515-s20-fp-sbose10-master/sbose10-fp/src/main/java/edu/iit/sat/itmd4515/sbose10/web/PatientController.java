/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.bose10.service.AppointmentService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import java.io.IOException;
import java.util.logging.Level;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import org.jboss.logging.Logger;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class PatientController {

    private static final Logger LOG = Logger.getLogger(PatientController.class.getName());

    private Patient patient;
    // private Appointment appointment;

    // private AppointmentController appointmentController;
    @EJB
    PatientService PatientSvc;

    @Inject
    LoginController loginController;

    /**
     *
     */
    public PatientController() {

    }

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the PatientController.postConstruct method");

        //  appointment = new Appointment();
        patient = new Patient();
        // PatientSvc.create(patient);
        // LOG.info("Inside the PatientController.postConstruct method updated"+ patient.getFirstname()); 

        //  appointment.setPatient(patient);
    }

    /**
     *method to redirect patient to the welcome page after booking an appointment
     * @return
     */
    public String savePatientDetails() {

        PatientSvc.create(patient);

        return "welcomePatient.xhtml";

    }

    /**
     *
     * @return
     */
    public Patient getPatient() {
        return patient;
    }

    /**
     *
     * @param patient
     */
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

}
