/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import javax.persistence.Entity;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author Sonita
 */
@Entity
@NamedQuery(name = "Doctor.findAll", query = "select d from Doctor d")
@NamedQuery(name = "Doctor.findById", query = "select d from Doctor d where d.id = :id")
@NamedQuery(name = "Doctor.findByFirstName", query = "select d from Doctor d where d.firstname = :firstname")
@NamedQuery(name = "Doctor.findByLastName", query = "select d from Doctor d where d.lastname = :lastname")
@NamedQuery(name = "Doctor.findByUserName", query = "select d from Doctor d where d.user.userName = :userName")
public class Doctor extends Person {

    @ManyToMany
    @JoinTable(name = "doctor_patients",
            joinColumns = @JoinColumn(name = "doctor_id"),
            inverseJoinColumns = @JoinColumn(name = "patient_id"))
    private List<Patient> patients = new ArrayList<>();

    // inverse side of bi-directional ManyToMany
    @OneToMany(mappedBy = "Doctor")
    private List<Appointment> Appointments = new ArrayList<>();

    @OneToOne
    private Department department;

    /**
     *
     */
    public Doctor() {

    }

    /**
     *
     * @param firstname
     * @param lastname
     * @param dob
     * @param email
     */
    public Doctor(String firstname, String lastname, LocalDate dob, String email) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.dob = dob;
        this.email = email;
    }

    /**
     *list of appointments
     * @return
     */
    public List<Appointment> getApptList() {
        return Appointments;
    }

    /**
     *
     * @param Appointments
     */
    public void setApptList(List<Appointment> Appointments) {
        this.Appointments = Appointments;
    }

    /**
     *
     * @param p
     */
    public void addPatient(Patient p) {
        if (!this.patients.contains(p)) {
            this.patients.add(p);
        }
        if (!p.getDoctor().contains(this)) {
            p.getDoctor().add(this);
        }
    }

    /**
     *
     * @param p
     */
    public void removePatient(Patient p) {
        if (this.patients.contains(p)) {
            this.patients.remove(p);
        }
        if (p.getDoctor().contains(this)) {
            p.getDoctor().remove(this);
        }
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + "firstName=" + firstname + ", lastName=" + lastname + ", dob=" + dob + ", email=" + email + '}';
    }

    /**
     *
     * @return
     */
    public Department getDepartment() {
        return department;
    }

    /**
     *
     * @param department
     */
    public void setDepartment(Department department) {
        this.department = department;
    }

    /**
     *
     * @return
     */
    public List<Patient> getPatients() {
        return patients;
    }

    /**
     *
     * @param patients
     */
    public void setPatients(List<Patient> patients) {
        this.patients = patients;
    }

}
