/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 *
 * @author Sonita
 */
@Entity
@NamedQuery(name = "Patient.findAll", query = "select p from Patient p")
@NamedQuery(name = "Patient.findById", query = "select p from Patient p where p.id = :id")
@NamedQuery(name = "Patient.findByFirstName", query = "select p from Patient p where p.firstname = :firstname")
@NamedQuery(name = "Patient.findByLastName", query = "select p from Patient p where p.lastname = :lastname")
@NamedQuery(name = "Patient.findByUserName", query = "select p from Patient p where p.user.userName = :userName")
public class Patient extends Person {

    // inverse side of bi-directional ManyToMany
    @ManyToMany(mappedBy = "patients")
    private List<Doctor> doctors = new ArrayList<>();

    // @OneToOne
    //private Appointment appointment;
    
    /**
     *
     */
    public Patient() {

    }

    /**
     *
     * @param string
     * @param ld
     * @param string1
     * @param string2
     */
    public Patient(String firstname, String lastname, LocalDate dob, String email) {
        super(firstname, lastname, dob, email);
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + "firstName=" + firstname + ", lastName=" + lastname + ", dob=" + dob + ", email=" + email + '}';
    }

    /**
     *
     * @return
     */
    public List<Doctor> getDoctor() {
        return doctors;
    }

    /**
     *
     * @param doctor
     */
    public void setDoctor(List<Doctor> doctor) {
        this.doctors = doctor;
    }

}
