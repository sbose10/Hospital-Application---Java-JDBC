/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;

import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.bose10.domain.Department;
import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import edu.iit.sat.itmd4515.bose10.domain.HcDepartment;
import edu.iit.sat.itmd4515.bose10.domain.HealthCare;
import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.domain.security.Group;
import edu.iit.sat.itmd4515.bose10.domain.security.User;
import edu.iit.sat.itmd4515.sbose10.web.HealthCareServlet;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Sonita
 */
@Startup
@Singleton
public class StartUpDatabaseLoaderService {

    private static final Logger LOG = Logger.getLogger(StartUpDatabaseLoaderService.class.getName());

    @PersistenceContext(name = "itmd4515")
    private EntityManager em;

    @EJB
    DepartmentService departmentSvc;
    @EJB
    PatientService patientSvc;
    @EJB
    DoctorService doctorSvc;
    @EJB
    AppointmentService appointmentSvc;
    @EJB
    HealthcareService healthcareSvc;

    // security services
    @EJB
    UserService userSvc;
    @EJB
    GroupService groupSvc;

    /**
     *
     */
    public StartUpDatabaseLoaderService() {
    }

    @PostConstruct
    private void postConstruct() {

        // seed the security domain first
        User admin = new User("admin", "admin", true);
        Group adminGroup = new Group("ADMIN_GROUP", "Group of administrators");
        admin.addGroup(adminGroup);
        

        groupSvc.create(adminGroup);
        

        Group doctorGroup = new Group("DOCTOR_GROUP", "Group of Doctors");
        Group patientGroup = new Group("PATIENT_GROUP", "Group of Patients");
        groupSvc.create(doctorGroup);
        groupSvc.create(patientGroup);
        
       // admin.addGroup(doctorGroup);
        admin.addGroup(patientGroup);
        userSvc.create(admin);

        User doctor1 = new User("doctor1", "doctor1", true);
        doctor1.addGroup(patientGroup);
        doctor1.addGroup(doctorGroup);

        User doctor2 = new User("doctor2", "doctor2", true);
        doctor2.addGroup(patientGroup);
        doctor2.addGroup(doctorGroup);
        
        User doctor3 = new User("doctor3", "doctor3", true);
        doctor3.addGroup(patientGroup);
        doctor3.addGroup(doctorGroup);
        
        User doctor4 = new User("doctor4", "doctor4", true);
       doctor4.addGroup(patientGroup);
        doctor4.addGroup(doctorGroup);
        
        User doctor5 = new User("doctor5", "doctor5", true);
        doctor5.addGroup(patientGroup);
        doctor5.addGroup(doctorGroup);

        User patient1 = new User("patient1", "patient1", true);
       // patient1.addGroup(adminGroup);
        patient1.addGroup(patientGroup);

        User patient2 = new User("patient2", "patient2", true);
      //  patient2.addGroup(adminGroup);
        patient2.addGroup(patientGroup);
        
        User patient3 = new User("patient3", "patient3", true);
       // patient3.addGroup(adminGroup);
        patient3.addGroup(patientGroup);
       
        User patient4 = new User("patient4", "patient4", true);
      //  patient4.addGroup(adminGroup);
        patient4.addGroup(patientGroup);

        userSvc.create(doctor1);
        userSvc.create(doctor2);
        userSvc.create(doctor3);
        userSvc.create(doctor4);
        userSvc.create(doctor5);
        userSvc.create(patient1);
        userSvc.create(patient2);
        userSvc.create(patient3);
        userSvc.create(patient4);

        /*
        userSvc.create(doctor1);
        userSvc.create(doctor2);
        userSvc.create(patient1);
        userSvc.create(patient2);

         */
        LOG.info("Doctor's Data ");
        Doctor d1 = new Doctor("Doctor1", "Daniel", LocalDate.of(2000, Month.JANUARY, 1), "d1@gmail.com");
        d1.setUser(doctor1);
        Doctor d2 = new Doctor("Doctor2", "Brook", LocalDate.of(1994, Month.MARCH, 1), "d2@gmail.com");
        d2.setUser(doctor2);
        Doctor d3 = new Doctor("Doctor3", "Candice", LocalDate.of(1990, Month.DECEMBER, 1), "d3@gmail.com");
        d3.setUser(doctor3);
        Doctor d4 = new Doctor("Doctor4", "Bryan", LocalDate.of(1990, Month.DECEMBER, 1), "d4@gmail.com");
        d4.setUser(doctor4);
        Doctor d5 = new Doctor("Doctor5", "Coddy", LocalDate.of(1990, Month.DECEMBER, 1), "d5@gmail.com");
        d5.setUser(doctor5);
        
        LOG.info("Doctor's First Name " + d1.getFirstname());
        LOG.info("Doctor's Last Name " + d1.getLastname());
        LOG.info("Doctor's Email" + d1.getEmail());
        LOG.info("Doctor's Date of Birth " + d1.getDob());
        //em.persist(d1);
        //em.persist(d2);
        //em.persist(d3);
        //em.persist(d4);
        //em.persist(d5);

        doctorSvc.create(d1);
        doctorSvc.create(d2);
        doctorSvc.create(d3);
        doctorSvc.create(d4);
        doctorSvc.create(d5);

        LOG.info("Appointment Datails ");
        Appointment ap1 = new Appointment("Headache", LocalDateTime.of(2021, 5, 5, 10, 0), LocalDateTime.of(2020, Month.JUNE, 30, 10, 0));
        Appointment ap2 = new Appointment("Eye infection", LocalDateTime.of(2021, 5, 5, 03, 10), LocalDateTime.of(2020, Month.MAY, 9, 10, 0));
        Appointment ap3 = new Appointment("Stomach Pain", LocalDateTime.of(2021, 5, 5, 13, 20), LocalDateTime.of(2020, Month.MAY, 9, 10, 0));
        Appointment ap4 = new Appointment("Cancer", LocalDateTime.of(2021, 5, 5, 12, 40), LocalDateTime.of(2020, Month.MAY, 9, 10, 0));
        Appointment ap5 = new Appointment("Fever", LocalDateTime.of(2021, 6, 5, 11, 50), LocalDateTime.of(2020, Month.APRIL, 9, 10, 0));

        ap1.setDoctor(d3);
        ap2.setDoctor(d2);
        ap3.setDoctor(d1);
        ap4.setDoctor(d4);
        ap5.setDoctor(d5);

        LOG.info("Symptom " + ap1.getSymptom());
        LOG.info("Appointment Details  " + ap1.getAptTime());

        //em.persist(ap1);
        //em.persist(ap2);
        //em.persist(ap3);
        //em.persist(ap4);
        //em.persist(ap5);
        appointmentSvc.create(ap1);
        appointmentSvc.create(ap2);
        appointmentSvc.create(ap3);
        appointmentSvc.create(ap4);
        appointmentSvc.create(ap5);

        LOG.info("Patient Datails ");
        Patient p1 = new Patient("Patient1", "Monroe", LocalDate.of(1993, Month.SEPTEMBER, 23), "p1@gmail.com");
        p1.setUser(patient1);
        Patient p2 = new Patient("Patient2", "Jackson", LocalDate.of(1982, Month.JUNE, 24), "p2@gmail.com");
        p2.setUser(patient2);
        Patient p3 = new Patient("Patient3", "Claire", LocalDate.of(1989, Month.OCTOBER, 12), "p3@gmail.com");
        p3.setUser(patient3);
        Patient p4 = new Patient("Patient4", "Rita", LocalDate.of(1999, Month.JANUARY, 12), "p4@gmail.com");
        p4.setUser(patient4);
        
        
        ap1.setPatient(p1);
        ap2.setPatient(p2);
        ap3.setPatient(p3);
        ap4.setPatient(p3);
        ap5.setPatient(p4);

        d1.addPatient(p3);
        d2.addPatient(p4);
        d3.addPatient(p2);
        d4.addPatient(p2);
        d5.addPatient(p1);

        LOG.info("Patient's Firstname " + p1.getFirstname());
        LOG.info("Patient's Lastname " + p1.getLastname());
        LOG.info("Patient's Date of Birth " + p1.getEmail());
        LOG.info("Doctor associated with Patient 1 " + p1.getDoctor());

        //em.persist(p1);
        //em.persist(p2);
        //em.persist(p3);
        //em.persist(p4);
        patientSvc.create(p1);
        patientSvc.create(p2);
        patientSvc.create(p3);
        patientSvc.create(p4);

        LOG.info("Department Datails ");

        Department dpt1 = new Department(HcDepartment.GAS);
        Department dpt2 = new Department(HcDepartment.GEN);
        Department dpt3 = new Department(HcDepartment.NEU);
        Department dpt4 = new Department(HcDepartment.ONC);
        Department dpt5 = new Department(HcDepartment.OPT);

        d1.setDepartment(dpt1);
        d2.setDepartment(dpt5);
        d3.setDepartment(dpt3);
        d4.setDepartment(dpt4);
        d5.setDepartment(dpt2);

        LOG.info("Department " + dpt1.getHcDepartment());
        LOG.info("Department " + dpt2.getHcDepartment());
        LOG.info("Department " + dpt3.getHcDepartment());

        departmentSvc.create(dpt1);
        departmentSvc.create(dpt5);
        departmentSvc.create(dpt3);
        departmentSvc.create(dpt4);
        departmentSvc.create(dpt2);

        //em.persist(dpt1);
        //em.persist(dpt5);
        //em.persist(dpt3);
        //em.persist(dpt4);
        //em.persist(dpt2);
    }

}
