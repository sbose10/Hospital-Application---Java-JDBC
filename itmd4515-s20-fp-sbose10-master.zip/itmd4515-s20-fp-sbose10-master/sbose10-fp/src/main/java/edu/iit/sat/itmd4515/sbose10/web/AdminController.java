/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.domain.security.Group;
import edu.iit.sat.itmd4515.bose10.domain.security.User;
import edu.iit.sat.itmd4515.bose10.service.DoctorService;
import edu.iit.sat.itmd4515.bose10.service.GroupService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import edu.iit.sat.itmd4515.bose10.service.UserService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.enterprise.SecurityContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class AdminController {

    /**
     *
     */
    public AdminController() {
    }

    private static final Logger LOG = Logger.getLogger(AdminController.class.getName());

    @Inject
    private SecurityContext securityContext;
    @Inject
    private FacesContext facesContext;

    @EJB
    private DoctorService docSvc;
    
    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the SignUpController.postConstruct method");
        

    }

    /**
     *methods to redirect pages for admin functionalities when adding a doctor
     *by an admin
     * @return
     */
    public String addDoctor() {
        return "/Admin/addDoc.xhtml?faces-redirect=true";

    }
     
    /**
     *methods to redirect pages for admin functionalities when deleting a doctor
     *by an admin
     * @return
     */
    public String delDoctor() {
        return "/Admin/deleteDocAdmin.xhtml?faces-redirect=true";

    }

    /**
     *methods to redirect pages for admin functionalities when viewing a doctor
     *by an admin
     * @return
     */
    public String viewDoctor() {
        return "/Admin/viewAllDocsAdmin.xhtml?faces-redirect=true";

    }

}
