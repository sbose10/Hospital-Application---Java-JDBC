/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.bose10.domain.HcDepartment;
import edu.iit.sat.itmd4515.bose10.domain.HealthCare;
import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.service.AppointmentService;
import edu.iit.sat.itmd4515.bose10.service.HealthcareService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.UserTransaction;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

/**
 *
 * @author Sonita
 */
@WebServlet(name = "HealthCareServlet", urlPatterns = {"/hcs"})
public class HealthCareServlet extends HttpServlet {

    private static final Logger LOG = Logger.getLogger(HealthCareServlet.class.getName());

    @PersistenceContext(name = "itmd4515PU")
    EntityManager em;

    @Resource
    Validator validator;

    @EJB
    HealthcareService healthcareSvc;
    @EJB
    PatientService patientSvc;
    @EJB
    AppointmentService appointmentSvc;

    @Resource
    UserTransaction tx;

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        //String HcDept = request.getParameter("HcDepartment");
        HealthCare hc = new HealthCare();
        request.setAttribute("hc", hc);
        request.setAttribute("HcDepartment", HcDepartment.values());
        // System.out.println("Printing Values");

        LOG.info("This is doGet of HealthCare Servlet ");

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/HealthCareJsp.jsp");
        dispatcher.forward(request, response);

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        LOG.info("This is doPost of HealthCare Servlet ");

        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String age = request.getParameter("age");
        String dob = request.getParameter("dob");
        String email = request.getParameter("email");
        String AppointmentDate = request.getParameter("AppointmentDate");
        String Symptom = request.getParameter("Symptom");
        System.out.println("Printing symptom");
        String HcDept = request.getParameter("HcDepartment");
        String AptID = request.getParameter("AptID");
        // String aptd = request.getParameter("aptd");

        LOG.info("Parameter Caught for fname" + fname);
        LOG.info("Parameter Caught which is nonexistant" + request.getParameter("nonexistant"));
        LOG.info("Parameter Caught for lname" + lname);
        LOG.info("Parameter Caught for age" + age);
        LOG.info("Parameter Caught for email" + email);
        LOG.info("Parameter Caught for appointmentDate" + AppointmentDate);
        LOG.info("Parameter Caught for Symptom" + Symptom);
        LOG.info("Parameter Caught for department" + HcDept);
        LOG.info("Parameter Caught for AptID" + AptID);
        //LOG.info("Parameter Caught for AptID" + aptd);

        LocalDateTime hcAppointmentDate = null;

        if (AppointmentDate != null && !(AppointmentDate.isEmpty())) {
            // hcAppointmentDate = LocalDate.of(LocalDate.parse(AppointmentDate), LocalDate.now());
            hcAppointmentDate = LocalDateTime.parse(AppointmentDate);
        }
        /*
        if(HcDept.equals("NON")){
            Set<String> deptViolations = new HashSet<String>();
            deptViolations.add("Department not selected");
             request.setAttribute("mistakes", deptViolations);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/HealthCareJsp.jsp");
            dispatcher.forward(request, response);
         */
        //  }
        /* if (aptd != null && !(aptd.isEmpty()) && aptd.equals(LocalTime.now())) {
            hcAppointmentDate = LocalDateTime.of(LocalDate.parse(aptd), LocalTime.now());
            hcAppointmentDate = LocalDateTime.of(LocalDate.parse(aptd), LocalTime.now());

        }*/
        Patient p1 = new Patient(fname, lname, LocalDate.parse(dob), email);
        Appointment ap1 = new Appointment(Symptom, LocalDateTime.parse(AppointmentDate), LocalDateTime.now());

        //HealthCare hc = new HealthCare(fname, lname, Integer.SIZE, email, exAppointmentDate, AptID, HcDepartment.valueOf(HcDept));
        //HealthCare hc = new HealthCare(fname, lname, Integer.SIZE, email, exAppointmentDate, Symptom, HcDepartment.valueOf(HcDept), AptID);
        HealthCare hc = new HealthCare(fname, lname, Integer.SIZE, email, hcAppointmentDate.toLocalDate(), Symptom, HcDepartment.valueOf(HcDept), AptID);

        //   HealthCare hc = new HealthCare(fname, lname, Integer.SIZE, email, hcAppointmentDate, hcAppointmentDate, Symptom,HcDepartment.valueOf(HcDept), AptID);
        //  LOG.info("Constructed instance:" + hc.toString());
        LOG.info("Constructed instance:" + ap1.toString());

        try {
            //   Set<ConstraintViolation<HealthCare>> violations = validator.validate(hc);
            Set<ConstraintViolation<Appointment>> violations_appt = validator.validate(ap1);
            Set<ConstraintViolation<Patient>> violations_patient = validator.validate(p1);

            if (violations_appt.size() > 0 && violations_patient.size() > 0) {
                LOG.info("Validation issue-Stop the launch!");
                //   for (ConstraintViolation<HealthCare> violation : violations) {
                for (ConstraintViolation<Appointment> violation1 : violations_appt) {
                    LOG.info(violation1.getPropertyPath() + " " + violation1.getMessage());
                }
                for (ConstraintViolation<Patient> violation2 : violations_patient) {
                    LOG.info(violation2.getPropertyPath() + " " + violation2.getMessage());
                }
                
            
            
            
            
         

                request.setAttribute("AppointmentDate", hc.getAppointmentDate().toString());
                //request.setAttribute("aptd", hc.getAptd().toLocalDate().atTime(LocalTime.MIN).toString());

                request.setAttribute("HcDepartment", HcDepartment.values());
                request.setAttribute("hc", hc);
                request.setAttribute("mistakes", violations_appt);
                   request.setAttribute("mistakes_patient", violations_patient);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/HealthCareJsp.jsp");
                dispatcher.forward(request, response);

            } else {

                LOG.info("Validation has passed!");

                //  Patient p1 = new Patient(fname, lname, LocalDate.parse(dob), email);
                //  Appointment ap1 = new Appointment(Symptom, LocalDateTime.parse(AppointmentDate), LocalDateTime.now());
                ap1.setPatient(p1);

                //request.setAttribute("AppointmentDate", hc.getAppointmentDate().toLocalDate().toString());
                //request.setAttribute("HcDepartment", HcDepartment.values());
                request.setAttribute("hcAptdate", AppointmentDate);
                request.setAttribute("hcSymptom", Symptom);
                request.setAttribute("hcAptID", AptID);

                request.setAttribute("hcDept", HcDepartment.valueOf(HcDept));
                //request.setAttribute("aptd", aptd);

                request.setAttribute("hc", hc);
                //request.setAttribute("mistakes", violations);

                RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/confirmJsp.jsp");
                dispatcher.forward(request, response);

                //tx.begin();
                //em.persist(hc);
                //em.persist(p1);
                // em.persist(ap1);
                // tx.commit();
                //  healthcareSvc.create(hc);
                // healthcareSvc.create(p1);
                patientSvc.create(p1);
                appointmentSvc.create(ap1);
            }
        } catch (Exception e) {
            Logger.getLogger(HealthCareServlet.class.getName()).log(Level.SEVERE, null, e);

        }

    }
    
    
    
    
    
    
    
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
