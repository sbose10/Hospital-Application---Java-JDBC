/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.security.User;
import edu.iit.sat.itmd4515.bose10.service.UserService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.enterprise.AuthenticationStatus;
import javax.security.enterprise.SecurityContext;
import javax.security.enterprise.authentication.mechanism.http.AuthenticationParameters;
import javax.security.enterprise.credential.Credential;
import javax.security.enterprise.credential.Password;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class LoginController {

    /*
    @NotBlank(message = "Enter username")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;
    */
    
     @Inject
    private UserService userSvc;

    private User user;

    /**
     * Constructor
     */
    public LoginController() {
    }

    private static final Logger LOG = Logger.getLogger(LoginController.class.getName());

    @Inject
    private SecurityContext securityContext;
    @Inject
    private FacesContext facesContext;

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the LoginController.postConstruct method");
 
                // if authenticated, find the user by username
        if (facesContext.getExternalContext().getRemoteUser() != null) {
            user = userSvc.findByUsername(facesContext.getExternalContext().getRemoteUser());
        } else {
            //else, instantiate a new user object for the login form
            user = new User();
        }

    }

    // helper methods

    /**
     *method to get the user based on username from the user table
     * @return
     */
    public String getAuthenticatedUser() {
        
        return user.getUserName();

    }

    /**
     *method to get a list of the user groups like admin doctor patient
     * @return
     */
    public String getAuthenticatedUserGroups() {
        
        
        user = userSvc.findByUsername(getAuthenticatedUser());
        LOG.info("User as group count of: " + user.getGroups().size());
        return user.getGroups().toString();


    }

    /**
     *setting roles 
     * @return
     */
    public boolean isAdmin() {
        return securityContext.isCallerInRole("ADMIN_ROLE");
    }

    /**
     *setting roles 
     * @return
     */
    public boolean isDoctor() {
        return securityContext.isCallerInRole("DOCTOR_ROLE");
    }

    /**
     *setting roles 
     * @return
     */
    public boolean isPatient() {
        return securityContext.isCallerInRole("PATIENT_ROLE");
    }

    // Action Methods

    /**
     *method to set credentials based on username
     * @return
     */
    public String doLogin() {
        LOG.info("LoginController.doLogin for user " + user.getUserName());

        Credential credential = new UsernamePasswordCredential(user.getUserName(), new Password(user.getPassword()));

        AuthenticationStatus status = securityContext.authenticate(
                (HttpServletRequest) facesContext.getExternalContext().getRequest(),
                (HttpServletResponse) facesContext.getExternalContext().getResponse(),
                AuthenticationParameters.withParams().credential(credential)
        );

        LOG.info("Authentication Status is " + status.toString());

        switch (status) {
            case SEND_CONTINUE:
                LOG.info("Received SEND_CONTINUE");
                break;
            case SEND_FAILURE:
                LOG.info("Received SEND_FAILURE");
                return "/error.xhtml";
            case SUCCESS:
                LOG.info("Received SUCCESS");
                break;
            case NOT_DONE:
                LOG.info("Received NOT_DONE");
                return "/error.xhtml";
        }
        return "/welcome.xhtml?faces-redirect=true";
    }
    
    /**
     *Redirecting to the signUp page 
     * @return
     */
    public String doRegister() {
       return "/signUp.xhtml?faces-redirect=true";
     }

    /**
     *Method to Logout
     * @return
     */
    public String doLogout() {

        LOG.info("LoginController.doLogout for user " + getAuthenticatedUser());

        HttpServletRequest req = (HttpServletRequest) facesContext.getExternalContext().getRequest();
        try {
            req.logout();
        } catch (ServletException ex) {
            LOG.log(Level.SEVERE, null, ex);
            return "/error.xhtml";
        }
        return "/login.xhtml?faces-redirect=true";
    }

    /**
     *
     * @return
     */
    public User getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }

}
