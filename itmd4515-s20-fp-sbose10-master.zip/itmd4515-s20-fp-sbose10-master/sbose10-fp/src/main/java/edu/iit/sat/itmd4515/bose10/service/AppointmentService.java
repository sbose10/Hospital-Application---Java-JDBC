/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;

import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.sbose10.web.LoginController;
import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import java.util.logging.Logger;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author Sonita
 */
@Named
@Stateless
public class AppointmentService extends AbstractService<Appointment> {

    private static final Logger LOG = Logger.getLogger(AppointmentService.class.getName());

    /**
     * constructor
     */
    public AppointmentService() {
        super(Appointment.class);
    }

    @EJB
    DoctorService doctorSvc;

    @Inject
    LoginController loginController;

    /**
     * a List of all appointments
     *
     * @return
     */
    @Override
    public List<Appointment> findAll() {
        return em.createNamedQuery("Appointment.findAll", entityClass).getResultList();

    }

    /**
     * returns the list of appointments based on doctor selected
     *
     * @return
     */
    public List<Appointment> findMyAppointments() {
        Doctor doc = doctorSvc.findByUsername(loginController.getAuthenticatedUser());
        LOG.info("Inside AppointmentService :: Doctor: " + doc.getFirstname());
        return em.createNamedQuery("Appointment.findMyAppointments", entityClass).setParameter("id", doc.getId()).getResultList();

    }

}
