/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.domain;

import edu.iit.sat.itmd4515.bose10.domain.security.User;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToOne;
import javax.persistence.PostLoad;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 *
 * @author Sonita
 */
@MappedSuperclass
public class Person extends EntityID {

    /**
     *constraint validation for firstname
     */
    @NotBlank(message = "Please enter your first name - required")
    @Column(nullable = false)
    @Size(min = 2, max = 20)
    protected String firstname;

    /**
     *constraint validation for lastname
     */
    @NotBlank(message = "Please enter your last name - required")
    @Column(nullable = false)
    @Size(min = 2, max = 20)
    protected String lastname;

    /**
     *declaring date of birth
     */
    protected LocalDate dob;

    /**
     *declaring email with the @email annotation
     */
    @Email
    protected String email;

    @Transient
    private Integer age;

    @OneToOne
    @JoinColumn(name ="USERNAME")
    private User user;

    /**
     *constructor
     */
    public Person() {
    }

    /**
     *
     * @param firstname
     * @param lastname
     * @param dob
     * @param email
     */
    public Person(String firstname, String lastname, LocalDate dob, String email) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.dob = dob;
        this.email = email;
    }

    @PostLoad
    private void calcAge() {
        if (this.dob != null) {
            this.age = Period.between(dob, LocalDate.now()).getYears();
        }
    }

    /**
     *
     * @return
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     *
     * @param firstname
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     *
     * @return
     */
    public String getLastname() {
        return lastname;
    }

    /**
     *
     * @param lastname
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     *
     * @return
     */
    public LocalDate getDob() {
        return dob;
    }

    /**
     *
     * @param dob
     */
    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    /**
     *
     * @return
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Person{" + "firstName=" + firstname + ", lastName=" + lastname + ", dob=" + dob + ", email=" + email + '}';
    }

    /**
     *
     * @return
     */
    public Integer getAge() {
        return age;
    }

    /**
     *
     * @param age
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     *
     * @return
     */
    public User getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(User user) {
        this.user = user;
    }

}
