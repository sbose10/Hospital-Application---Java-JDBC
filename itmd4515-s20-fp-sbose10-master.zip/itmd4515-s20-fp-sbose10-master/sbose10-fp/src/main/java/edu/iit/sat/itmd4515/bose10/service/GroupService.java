/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;
import  edu.iit.sat.itmd4515.bose10.domain.security.Group;
import edu.iit.sat.itmd4515.bose10.domain.security.User;

import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author Sonita
 */
@Stateless
public class GroupService extends AbstractService<Group> {
    
    /**
     *
     */
    public GroupService() {
        super(Group.class);
    }

    /**
     *list of user groups, admin doctor and patients
     * @return
     */
    @Override
    public List<Group> findAll() {
        return em.createNamedQuery("Group.findAll", entityClass).getResultList();
    }
    
    /**
     *list of group names
     * @param groupname
     * @return
     */
   
    
     public Group findByGroupname(String groupname) {
        return em.find(Group.class, groupname);
    }
    


    /**
     *list of user names
     * @param groupname
     * @return
     */

    public Group findByUsername(String groupname) {
        return em.find(Group.class, groupname);
    }
    
}
