/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;

import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.bose10.domain.Patient;
import edu.iit.sat.itmd4515.bose10.service.AppointmentService;
import edu.iit.sat.itmd4515.bose10.service.DoctorService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import org.jboss.logging.Logger;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class DoctorController {

    private static final Logger LOG = Logger.getLogger(DoctorController.class.getName());

    private Doctor doctor;
    String docId;

    @EJB
    AppointmentService appointmentSvc;
    PatientService patientSvc;

    @EJB
    DoctorService doctorSvc;
    private Appointment appointment;
    private Patient patient;

    private List<Doctor> doctors;

    /**
     *
     */
    public DoctorController() {

    }

    @PostConstruct
    private void postContruct() {
        LOG.info("Inside the DoctorController.postConstruct method");
        doctor = new Doctor();
        appointment = new Appointment();
    }

    /**
     *method for admins to view appointments
     * @param app
     * @return
     */
    public String viewAppointment(Appointment app) {
        LOG.info("DoctorController viewAppointment method " + app.toString());
        this.appointment = app;
        return "/Doctor/viewDoctorAppointment.xhtml";
    }

    /**
     *method for admin to delete doctors
     * @param docId
     * @return 
     */
    public String deleteDoctor(String docId)
    {
        LOG.info("DoctorController deleteDoctor Doc to be deleted "+docId);
       try
       {
      doctorSvc.removeDoctor(Long.parseLong(docId));
       }
        catch(Exception exp)
        {
             return "unauthorizedErrorPage.xhtml";
        }
                
        return "";
        
    }
    /**
     *method for doctor to view appointments
     * @return
     */
    public String viewAppointments() {
        LOG.info("DoctorController viewAppointments method ");

        return "/Doctor/DoctorAppointments.xhtml";
    }

    /**
     *method to initialize the appointment to get the appointment id
     */
    public void initAppointmentById() {
        LOG.info("DoctorController initAppointmentById with " + this.appointment.getId());
        appointment = appointmentSvc.find(this.appointment.getId());
        LOG.info("DoctorController initAppointmentById after find " + this.appointment.toString());
    }

    /**
     *the method to save the appointment for patients for the save appointment button
     * @return
     */
    public String saveAppointment() {
        LOG.info("DoctorController saveActivity with Appointment " + this.appointment.toString());
        LOG.info("DoctorController saveActivity with Doctor " + doctor.toString());
        
        doctorSvc.appointmentUpdate(appointment);
  
        return "welcomeDoctor.xhtml";

    }

    /**
     *method for doctor to remove appointments
     * @return
     */
    public String confirmAndRemoveAppointment() {
        LOG.info("DoctorController confirmAndRemoveActivity with " + this.appointment.toString());
        
        doctorSvc.appointmentDelete(appointment);
        
        return "welcomeDoctor.xhtmll";
    }

    /**
     *
     * @return
     */
    public Doctor getDoctor() {
        return doctor;
    }

    /**
     *
     * @param doctor
     */
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    /**
     *
     * @return
     */
    public List<Doctor> getAllDoctors() {
        doctors = doctorSvc.findAll();
        return doctors;
    }

    /**
     *
     * @return
     */
    public Patient getPatient() {
        return patient;
    }

    /**
     *
     * @param patient
     */
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    /**
     *method for patients to save appointment details
     * @return
     */
    public String saveAppointmentDetails() {
        LOG.info(" saveAppointmentDetails::Inside DoctorController: " + appointment.toString());
        // LOG.info(PatientController.getPatient() + "saveAppointmentDetails:: Inside Appointment: ");
        LOG.info("saveAppointmentDetails:: Inside DoctorController: " + patient.toString());
        doctor = doctorSvc.find(Long.parseLong(docId));
        LOG.info("saveAppointmentDetails:: Inside Doctor: " + doctor.toString());
        //  patientSvc.create(patient);
        //  appointment.setPatient(patientController.getPatient());
        appointment.setDoctor(doctor);
        appointmentSvc.create(appointment);

        return "welcomePatient.xhtml";

    }
    
    /**
     *
     * @return
     */
    public Appointment getAppointment() {
        return appointment;
    }

    /**
     *
     * @param appointment
     */
    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    /**
     *
     * @return
     */
    public String getDocId() {
        return docId;
    }

    /**
     *
     * @param docId
     */
    public void setDocId(String docId) {
        this.docId = docId;
    }

}
