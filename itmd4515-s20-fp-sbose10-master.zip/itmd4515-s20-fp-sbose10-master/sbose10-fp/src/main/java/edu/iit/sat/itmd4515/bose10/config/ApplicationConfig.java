/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.config;


import edu.iit.sat.itmd4515.bose10.domain.HcDepartment;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

/**
 *
 * @author Sonita
 */
@Named
@ApplicationScoped
public class ApplicationConfig {

    /**
     *
     */
    public ApplicationConfig() {
    }
    
    /**
     *
     * @return
     */
    public HcDepartment[] getHcDepartments() {
    
        return HcDepartment.values();
        }
}
    

    

