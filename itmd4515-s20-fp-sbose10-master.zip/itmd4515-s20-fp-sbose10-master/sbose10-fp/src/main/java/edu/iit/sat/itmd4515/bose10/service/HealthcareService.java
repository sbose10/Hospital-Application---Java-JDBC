/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;

import javax.ejb.Stateless;

import edu.iit.sat.itmd4515.bose10.domain.HealthCare;
import java.util.List;
/**
 *
 * @author Sonita
 */
@Stateless
public class HealthcareService extends AbstractService<HealthCare>  {

    /**
     *
     */
    public HealthcareService() {
        super(HealthCare.class);
    }

    /**
     *
     * @return
     */
    @Override
    public List<HealthCare> findAll() {
        return em.createNamedQuery("HealthCare.findAll", entityClass).getResultList();

    }
    
}
