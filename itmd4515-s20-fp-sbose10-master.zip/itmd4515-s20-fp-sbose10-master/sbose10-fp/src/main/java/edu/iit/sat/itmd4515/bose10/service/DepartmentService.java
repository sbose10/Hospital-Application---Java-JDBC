/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.bose10.service;

import edu.iit.sat.itmd4515.bose10.domain.Department;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Sonita
 */
@Stateless
public class DepartmentService {

    @PersistenceContext(name = "itmd4515PU")
    private EntityManager em;

    /**
     * constructor
     */
    public DepartmentService() {
    }

    // CRUD service operations
    /**
     *
     * @param dpt
     */
    public void create(Department dpt) {
        em.persist(dpt);
    }

    /**
     *
     * @param dpt
     */
    public void update(Department dpt) {
        em.merge(dpt);
    }

    /**
     *
     * @param dpt
     */
    public void remove(Department dpt) {
        em.remove(em.merge(dpt));
    }

    /**
     *
     * @param id
     * @return
     */
    public Department find(Long id) {
        return em.find(Department.class, id);
    }

    /**
     * list of all the departments
     *
     * @return
     */
    public List<Department> findAll() {
        return em.createNamedQuery("Department.findAll", Department.class).getResultList();
    }

}
