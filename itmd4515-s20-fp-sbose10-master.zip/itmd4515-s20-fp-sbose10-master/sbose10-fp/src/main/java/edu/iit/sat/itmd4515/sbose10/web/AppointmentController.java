/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.iit.sat.itmd4515.sbose10.web;


import edu.iit.sat.itmd4515.bose10.domain.Appointment;
import edu.iit.sat.itmd4515.bose10.domain.Doctor;
import edu.iit.sat.itmd4515.bose10.domain.Patient;
import java.util.logging.Logger;
import edu.iit.sat.itmd4515.bose10.service.AppointmentService;
import edu.iit.sat.itmd4515.bose10.service.DoctorService;
import edu.iit.sat.itmd4515.bose10.service.PatientService;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author Sonita
 */
@Named
@RequestScoped
public class AppointmentController {

    private static final Logger LOG = Logger.getLogger(AppointmentController.class.getName());

    /**
     *
     */
    public AppointmentController() {
    }

    private Doctor doctor;
    private Patient patient;
    private Appointment appointment;
    
    String docId;
    
   @EJB
   DoctorService doctorSvc;  
    
   @EJB
   PatientService patientSvc; 
   @Inject
   PatientController patientController;

    @Inject
    LoginController loginController;
      
    @EJB
    AppointmentService AppointmentSvc;

    private List<Doctor> doctors;
    
    @PostConstruct
    private void postContruct() {
     
      
            
       
        LOG.info("Inside the AppointmentController.postConstruct method ");
        LOG.info("auth user is"+loginController.getAuthenticatedUser().toString() );
        LOG.info("auth user Doctor "+loginController.isDoctor());
        LOG.info("auth user Patient "+loginController.isPatient());
      //  patient = new Patient();
        appointment = new Appointment();
      //  appointment.setPatient(patient);
     // doctor = doctorSvc.findByUsername(loginController.getAuthenticatedUser());
   // if(loginController.isPatient()) {
       patient = patientSvc.findByUsername(loginController.getAuthenticatedUser());
      LOG.info("Inside Appointment: Appointment details " + appointment.toString());
//       LOG.info("Inside Appointment Patient details Firstname: " + patient.getFirstname());
      appointment.setPatient(patient); 
    // }  
       //  LOG.info("Inside the AppointmentController.postconstuctpatient method"+ patient.getFirstname());
        
       
           
        
    }
        

    /**
     *method to save appointment details for patients
     *this is the method which also alerts the patient if the patient has
     *symptoms similar to covid 19
     * @return
     */
    public String saveAppointmentDetails() {
        LOG.info(" saveAppointmentDetails::Inside Appointment: " + appointment.toString());
            LOG.info("saveAppointmentDetails:: Inside Appointment: " + patientController.getPatient());
            LOG.info("saveAppointmentDetails:: Inside Appointment: " + patient.toString());
            doctor = doctorSvc.find(Long.parseLong(docId));
             LOG.info("saveAppointmentDetails:: Inside Doctor: " + doctor.toString());
      //  patientSvc.create(patient);
     //  appointment.setPatient(patientController.getPatient());
     appointment.setDoctor(doctor);
        AppointmentSvc.create(appointment);
        
        if(appointment.getSymptom().toLowerCase().contains("fever") && appointment.getSymptom().toLowerCase().contains("cough"))
        {
           return "alertPatient.xhtml"; 
        }
            
        return "welcomePatient.xhtml";

    }
    
    /**
     *
     * @return
     */
    public Appointment getAppointment() {
        return appointment;
    }

    /**
     *
     * @param appointment
     */
    public void setAppointment(Appointment appointment) {
        this.appointment = appointment;
    }

    /**
     *
     * @return
     */
    public Patient getPatient() {
        return patient;
    }

    /**
     *
     * @param patient
     */
    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    /**
     *
     * @return
     */
    public Doctor getDoctor() {
        return doctor;
    }

    /**
     *
     * @param doctor
     */
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    /**
     *List of all the doctors 
     * @return
     */
    public List<Doctor> getAllDoctors() {
        doctors= doctorSvc.findAll();
        return doctors;
    }

    /**
     *the doctors with their respective doctorId
     * @return
     */
    public String getDocId() {
        return docId;
    }

    /**
     *
     * @param docId
     */
    public void setDocId(String docId) {
        this.docId = docId;
    }

   

   

   
}
