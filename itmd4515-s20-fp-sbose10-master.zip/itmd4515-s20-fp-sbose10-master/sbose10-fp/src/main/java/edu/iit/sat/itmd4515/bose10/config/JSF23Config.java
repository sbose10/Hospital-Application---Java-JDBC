package edu.iit.sat.itmd4515.bose10.config;


import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.FacesConfig;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sonita
 */


@ApplicationScoped
@FacesConfig(version = FacesConfig.Version.JSF_2_3)
public class JSF23Config {
    
}
